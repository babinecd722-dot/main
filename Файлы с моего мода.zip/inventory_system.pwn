// ==== FULL INVENTORY SYSTEM ====
// Ïîëíàÿ ñèñòåìà èíâåíòàðÿ ïåðåíåñåííàÿ èç laird.pwn

// Êîíôèãóðàöèÿ èíâåíòàðÿ
#define INVENTORY_BASE_SLOTS 20
#define INVENTORY_VIP_SLOTS 20
#define MAX_INV_SLOTS (INVENTORY_BASE_SLOTS + INVENTORY_VIP_SLOTS)
#define MAX_ITEM_STACK 5
#define INVENTORY_ITEM_JERRICAN 21
#define INVENTORY_ITEM_MEDKIT 22
#define INVENTORY_ITEM_MEDICINE 66
#define INVENTORY_ITEM_REPAIR_KIT 23
#define INVENTORY_ITEM_MASK 116
#define INVENTORY_USE_HEAL_VALUE (60.0)
#define INVENTORY_MAX_EQUIPPED_ACCESSORIES 6

enum p_inv_info
{
    invItem,
    invCount,
    invValue
}

forward bool:CanPlayerReceiveItem(playerid, itemid, amount);

new PlayerInventory[MAX_PLAYERS][MAX_INV_SLOTS][p_inv_info];

stock ResetPlayerInventoryData(playerid)
{
    if(playerid < 0 || playerid >= MAX_PLAYERS) return 0;

    for(new i = 0; i < MAX_INV_SLOTS; i++)
    {
        PlayerInventory[playerid][i][invItem] = 0;
        PlayerInventory[playerid][i][invCount] = 0;
        PlayerInventory[playerid][i][invValue] = 0;
    }
    return 1;
}

stock SavePlayerInventoryAISnapshot(playerid)
{
    if(!IsPlayerConnected(playerid)) return 0;

    new account_id = GetPlayerAccountID(playerid);
    if(account_id <= 0) return 0;

    new query[256];

    new phone_number = GetPlayerPhone(playerid);
    if(phone_number > 0)
    {
        mysql_format(mysql, query, sizeof(query),
            "INSERT INTO player_inventory (account_id, slot, item_id, qty, text_param, modelid, is_slot) VALUES (%d, %d, %d, 1, '%d', %d, 1)",
            account_id, 255, 58, phone_number, phone_number);
        mysql_query(mysql, query, false);
    }

    new skin_model = GetPlayerSkin(playerid);
    if(skin_model <= 0) skin_model = GetPlayerSkinEx(playerid);
    if(skin_model > 0)
    {
        mysql_format(mysql, query, sizeof(query),
            "INSERT INTO player_inventory (account_id, slot, item_id, qty, text_param, modelid, is_slot) VALUES (%d, %d, %d, 1, '%d', %d, 1)",
            account_id, 6, 134, skin_model, skin_model);
        mysql_query(mysql, query, false);
    }

    for(new attach_slot = 0; attach_slot < MAX_PLAYER_ATTACHED_OBJECTS; attach_slot++)
    {
        if(!IsPlayerAttachedObjectSlotUsed(playerid, attach_slot)) continue;

        new modelid = floatround(gPlayerTempAccData[playerid][attach_slot][0]);
        if(modelid <= 0) continue;

        new internal_id = GetAccessoryInternalIdByModelId(modelid);
        if(internal_id == -1) continue;

        new inv_slot = GetInventoryAccessorySlotByAttachSlot(playerid, attach_slot);
        if(inv_slot < 0 || inv_slot >= INVENTORY_MAX_EQUIPPED_ACCESSORIES) continue;

        mysql_format(mysql, query, sizeof(query),
            "INSERT INTO player_inventory (account_id, slot, item_id, qty, text_param, modelid, is_slot) VALUES (%d, %d, %d, 1, '', %d, 1)",
            account_id, inv_slot, internal_id, modelid);
        mysql_query(mysql, query, false);
    }
    return 1;
}

stock SavePlayerInventory(playerid)
{
    if(!IsPlayerConnected(playerid)) return 0;

    new account_id = GetPlayerAccountID(playerid);
    if(account_id <= 0) return 0;

    new query[256];
    mysql_format(mysql, query, sizeof(query), "DELETE FROM player_inventory WHERE account_id=%d", account_id);
    mysql_query(mysql, query, false);
    new text_param[32];

    for(new slot = 0; slot < MAX_INV_SLOTS; slot++)
    {
        new item_id = PlayerInventory[playerid][slot][invItem];
        if(item_id <= 0) continue;

        new item_qty = PlayerInventory[playerid][slot][invCount];
        if(item_qty <= 0) item_qty = 1;

        new item_value = PlayerInventory[playerid][slot][invValue];

        format(text_param, sizeof(text_param), "%d", item_value);
        mysql_format(mysql, query, sizeof(query),
            "INSERT INTO player_inventory (account_id, slot, item_id, qty, text_param, modelid, is_slot) VALUES (%d, %d, %d, %d, '%e', %d, 0)",
            account_id, slot, item_id, item_qty, text_param, item_value);
        mysql_query(mysql, query, false);
    }

    SavePlayerInventoryAISnapshot(playerid);
    return 1;
}

stock LoadPlayerInventory(playerid)
{
    ResetPlayerInventoryData(playerid);

    if(!IsPlayerConnected(playerid)) return 0;

    new account_id = GetPlayerAccountID(playerid);
    if(account_id <= 0) return 0;

    new query[256];
    mysql_format(mysql, query, sizeof(query),
        "SELECT slot, item_id, qty, text_param, modelid, is_slot FROM player_inventory WHERE account_id=%d ORDER BY is_slot ASC, slot ASC, id ASC",
        account_id);

    new Cache:result = mysql_query(mysql, query, true);
    new rows = cache_num_rows();
    if(!rows)
{
    cache_delete(result);
    return 1;
}


    new text_param[33];
    for(new i = 0; i < rows; i++)
    {
        new item_id = cache_get_field_content_int(i, "item_id");
        if(item_id <= 0) continue;

        new item_value = cache_get_field_content_int(i, "modelid");
        if(item_value <= 0)
        {
            cache_get_field_content(i, "text_param", text_param, mysql, sizeof(text_param));
            if(text_param[0] != EOS) item_value = strval(text_param);
        }

        if(cache_get_field_content_int(i, "is_slot"))
        {
            switch(item_id)
            {
                case 58:
                {
                    if(item_value > 0)
                    {
                        SetPlayerData(playerid, P_PHONE, item_value);
                    }
                }
                case 134:
                {
                    if(item_value > 0)
                    {
                        SetPlayerData(playerid, P_SKIN, item_value);
                    }
                }
            }
            continue;
        }

        new slot = cache_get_field_content_int(i, "slot");
        if(slot < 0 || slot >= MAX_INV_SLOTS) continue;
        if(PlayerInventory[playerid][slot][invItem] > 0) continue;

        new item_qty = cache_get_field_content_int(i, "qty");
        if(item_qty <= 0) item_qty = 1;
        if(item_id == INVENTORY_ITEM_MEDKIT || item_id == INVENTORY_ITEM_REPAIR_KIT)
        {
            if(item_qty > MAX_ITEM_STACK) item_qty = MAX_ITEM_STACK;
        }

        PlayerInventory[playerid][slot][invItem] = item_id;
        PlayerInventory[playerid][slot][invCount] = item_qty;
        PlayerInventory[playerid][slot][invValue] = item_value;
    }

    cache_delete(result);
    return 1;
}

stock GetPlayerInventorySlots(playerid)
{
    if(!IsPlayerConnected(playerid)) return INVENTORY_BASE_SLOTS;

    new slots = INVENTORY_BASE_SLOTS;
    if(GetPlayerPremium(playerid) > 0) slots += INVENTORY_VIP_SLOTS;

    if(slots > MAX_INV_SLOTS) slots = MAX_INV_SLOTS;
    return slots;
}

stock bool:IsInventoryFishingTackleItem(itemid)
{
    return (itemid >= 642 && itemid <= 646);
}

stock Float:GetInventoryItemUnitWeight(itemid)
{
    if(itemid < 0 || itemid > INVENTORY_WEIGHT_MAX_ITEM_ID) return 0.0;
    return g_inventory_item_weight[itemid];
}

stock Float:GetInventoryItemAddWeight(itemid)
{
    if(itemid < 0 || itemid > INVENTORY_WEIGHT_MAX_ITEM_ID) return 0.0;
    return g_inventory_item_addw[itemid];
}

stock GivePlayerInvSkin(playerid, skinid)
{
    if(!IsPlayerConnected(playerid) || skinid <= 0) return 0;
    if(!CanPlayerReceiveItem(playerid, 134, 1)) return 0;

    new active_slots = GetPlayerInventorySlots(playerid);
    new slot = -1;

    for(new i = 0; i < active_slots; i++)
    {
        if(PlayerInventory[playerid][i][invItem] == 0)
        {
            slot = i;
            break;
        }
    }

    if(slot == -1) return 0;

    PlayerInventory[playerid][slot][invItem] = 134;
    PlayerInventory[playerid][slot][invCount] = 1;
    PlayerInventory[playerid][slot][invValue] = skinid;
    return 1;
}

stock GetInventoryItemModelId(itemid)
{
    if(itemid < 0 || itemid > INVENTORY_WEIGHT_MAX_ITEM_ID) return -1;
    return g_inventory_item_modelid[itemid];
}

stock GetInventoryItemFold(itemid)
{
    if(itemid < 0 || itemid > INVENTORY_WEIGHT_MAX_ITEM_ID) return 0;
    return g_inventory_item_fold[itemid];
}

stock GetInventoryAccessoryItemIdByModelId(modelid)
{
    if(modelid <= 0) return -1;

    for(new itemid = 1; itemid <= INVENTORY_WEIGHT_MAX_ITEM_ID; itemid++)
    {
        if(g_inventory_item_modelid[itemid] != modelid) continue;
        if(g_inventory_item_fold[itemid] != 1) continue;
        return itemid;
    }
    return -1;
}

stock Float:GetPlayerInventoryMaxWeight(playerid)
{
    new Float:max_weight = 50.0;

    new skin = GetPlayerSkin(playerid);
    if(skin > 0)
    {
        max_weight += GetInventoryItemAddWeight(134);
    }

    new phone = GetPlayerPhone(playerid);
    if(phone > 0)
    {
        max_weight += GetInventoryItemAddWeight(58);
    }

    return max_weight;
}

stock Float:GetPlayerInventoryWeightF(playerid)
{
    new Float:weight = 0.0;

    new active_slots = GetPlayerInventorySlots(playerid);

    for(new i = 0; i < active_slots; i++)
    {
        new itemid = PlayerInventory[playerid][i][invItem];
        if(itemid <= 0) continue;

        new amount = PlayerInventory[playerid][i][invCount];
        if(amount <= 0) continue;

        weight += Float:amount * GetInventoryItemUnitWeight(itemid);
    }

    return weight;
}

stock GetPlayerInventoryWeight(playerid)
{
    return floatround(GetPlayerInventoryWeightF(playerid));
}

stock bool:CanPlayerReceiveItem(playerid, itemid, amount)
{
    new active_slots = GetPlayerInventorySlots(playerid);
    new bool:is_stackable = (itemid == INVENTORY_ITEM_MEDKIT || itemid == INVENTORY_ITEM_REPAIR_KIT);

    new capacity = 0;

    for(new i = 0; i < active_slots; i++)
    {
        if(PlayerInventory[playerid][i][invItem] == 0)
        {
            capacity += (is_stackable ? MAX_ITEM_STACK : 1);
        }
        else if(is_stackable
            && PlayerInventory[playerid][i][invItem] == itemid
            && PlayerInventory[playerid][i][invCount] < MAX_ITEM_STACK)
        {
            capacity += (MAX_ITEM_STACK - PlayerInventory[playerid][i][invCount]);
        }
    }

    if(capacity < amount) return false;

    new Float:current_weight = GetPlayerInventoryWeightF(playerid);
    new Float:max_weight = GetPlayerInventoryMaxWeight(playerid);
    new Float:added_weight = Float:amount * GetInventoryItemUnitWeight(itemid);

    if(current_weight + added_weight > max_weight) return false;

    return true;
}

stock GivePlayerItem(playerid, itemid, amount)
{
    if(!CanPlayerReceiveItem(playerid, itemid, amount)) return 0;
    return GivePlayerItemNoWeightCheck(playerid, itemid, amount);
}

stock UsePlayerInventorySim(playerid, inv_slot, &slot_code)
{
    new active_slots = GetPlayerInventorySlots(playerid);
    if(inv_slot < 0 || inv_slot >= active_slots) return 0;
    if(PlayerInventory[playerid][inv_slot][invItem] != 58) return 0;

    new sim_number = PlayerInventory[playerid][inv_slot][invValue];
    if(sim_number <= 0) return 0;

    new old_number = GetPlayerPhone(playerid);

    SetPlayerData(playerid, P_PHONE, sim_number);
    UpdatePlayerDatabaseInt(playerid, "phone", sim_number);

    if(old_number > 0)
    {
        // Меняем местами - старая сим уходит в слот
        PlayerInventory[playerid][inv_slot][invItem] = 58;
        PlayerInventory[playerid][inv_slot][invCount] = 1;
        PlayerInventory[playerid][inv_slot][invValue] = old_number;
    }
    else
    {
        // Старой сим не было - очищаем слот
        PlayerInventory[playerid][inv_slot][invItem] = 0;
        PlayerInventory[playerid][inv_slot][invCount] = 0;
        PlayerInventory[playerid][inv_slot][invValue] = 0;
    }

    slot_code = 255;
    return 1;
}

stock MovePlayerSimFromSlotToInventory(playerid, inv_slot)
{
    new active_slots = GetPlayerInventorySlots(playerid);
    if(inv_slot < 0 || inv_slot >= active_slots) return 0;
    if(PlayerInventory[playerid][inv_slot][invItem] != 0) return 0;

    new phone_number = GetPlayerPhone(playerid);
    if(phone_number <= 0) return 0;

    PlayerInventory[playerid][inv_slot][invItem] = 58;
    PlayerInventory[playerid][inv_slot][invCount] = 1;
    PlayerInventory[playerid][inv_slot][invValue] = phone_number;

    SetPlayerData(playerid, P_PHONE, 0);
    UpdatePlayerDatabaseInt(playerid, "phone", 0);
    return 1;
}

stock GivePlayerItemNoWeightCheck(playerid, itemid, amount)
{
    new active_slots = GetPlayerInventorySlots(playerid);
    new bool:is_stackable = (itemid == INVENTORY_ITEM_MEDKIT || itemid == INVENTORY_ITEM_REPAIR_KIT);
    new remaining = amount;

    if(is_stackable)
    {
        for(new i = 0; i < active_slots && remaining > 0; i++)
        {
            if(PlayerInventory[playerid][i][invItem] == itemid && PlayerInventory[playerid][i][invCount] < MAX_ITEM_STACK)
            {
                new can_add = MAX_ITEM_STACK - PlayerInventory[playerid][i][invCount];
                new to_add = (remaining < can_add) ? remaining : can_add;
                PlayerInventory[playerid][i][invCount] += to_add;
                remaining -= to_add;
            }
        }
    }

    for(new i = 0; i < active_slots && remaining > 0; i++)
    {
        if(PlayerInventory[playerid][i][invItem] == 0)
        {
            new to_add = 1;
            if(is_stackable)
            {
                to_add = (remaining < MAX_ITEM_STACK) ? remaining : MAX_ITEM_STACK;
            }
            PlayerInventory[playerid][i][invItem] = itemid;
            PlayerInventory[playerid][i][invCount] = to_add;
            PlayerInventory[playerid][i][invValue] = 0;
            remaining -= to_add;
        }
    }

    return (remaining == 0) ? 1 : 0;
}

stock GivePlayerSkin(playerid, skinid)
{
    new inv_slots = GetPlayerInventorySlots(playerid);

    for(new i = 0; i < inv_slots; i++)
    {
        if(PlayerInventory[playerid][i][invItem] == 134 && PlayerInventory[playerid][i][invValue] == skinid)
        {
            return 0;
        }
    }

    for(new i = 0; i < inv_slots; i++)
    {
        if(PlayerInventory[playerid][i][invItem] == 0)
        {
            PlayerInventory[playerid][i][invItem] = 134;
            PlayerInventory[playerid][i][invCount] = 1;
            PlayerInventory[playerid][i][invValue] = skinid;
            return 1;
        }
    }

    return 0;
}

stock bool:IsInventoryAccessoryItem(itemid)
{
    if(itemid <= 0 || itemid > INVENTORY_WEIGHT_MAX_ITEM_ID) return false;
    return (g_inventory_item_fold[itemid] == 1);
}

stock bool:IsInventoryMaskItem(itemid)
{
    return (itemid == INVENTORY_ITEM_MASK);
}

stock bool:IsInventoryMedkitItem(itemid)
{
    return (itemid == INVENTORY_ITEM_MEDKIT || itemid == INVENTORY_ITEM_MEDICINE);
}

stock bool:IsInventoryJerricanItem(itemid)
{
    return (itemid == INVENTORY_ITEM_JERRICAN);
}

stock ConsumePlayerInventoryItem(playerid, slot)
{
    if(slot < 0 || slot >= GetPlayerInventorySlots(playerid)) return 0;
    if(PlayerInventory[playerid][slot][invItem] <= 0) return 0;

    if(PlayerInventory[playerid][slot][invCount] > 1)
    {
        PlayerInventory[playerid][slot][invCount]--;
    }
    else
    {
        PlayerInventory[playerid][slot][invItem] = 0;
        PlayerInventory[playerid][slot][invCount] = 0;
        PlayerInventory[playerid][slot][invValue] = 0;
    }

    return 1;
}

stock UsePlayerInventoryItem(playerid, inv_slot, itemid, &slot_code, &new_skin)
{
    slot_code = -1;
    new_skin = 0;

    if(inv_slot < 0 || inv_slot >= GetPlayerInventorySlots(playerid)) return 0;
    if(PlayerInventory[playerid][inv_slot][invItem] != itemid) return 0;

// Скин
    if(itemid == 134)
    {
        new skinid = PlayerInventory[playerid][inv_slot][invValue];
        if(skinid <= 0) return 0;

        new old_skin = GetPlayerSkin(playerid);
        if(old_skin <= 0) old_skin = GetPlayerSkinEx(playerid);
        if(old_skin <= 0) old_skin = skinid;

        SetPlayerSkin(playerid, skinid);
        new_skin = skinid;

        new teamid = GetPlayerTeamEx(playerid);
        if(teamid < 1 || teamid >= 50)
        {
            SetPlayerData(playerid, P_SKIN, skinid);
        }

        // Old skin goes into the inventory slot
        PlayerInventory[playerid][inv_slot][invItem] = 134;
        PlayerInventory[playerid][inv_slot][invCount] = 1;
        PlayerInventory[playerid][inv_slot][invValue] = old_skin;

        slot_code = 6;
        return 1;
    }

// SIM-карта
    if(itemid == 58)
    {
        return UsePlayerInventorySim(playerid, inv_slot, slot_code);
    }

  // Медкит
    if(IsInventoryMedkitItem(itemid))
    {
        callcmd::healme(playerid, "");
        ConsumePlayerInventoryItem(playerid, inv_slot);
        slot_code = inv_slot;
        return 1;
    }

    // Ремкомплект
    if(itemid == INVENTORY_ITEM_REPAIR_KIT)
    {
        new vehicleid = INVALID_VEHICLE_ID;
        
        if(IsPlayerDriver(playerid))
        {
            vehicleid = GetPlayerVehicleID(playerid);
        }
        else
        {
            vehicleid = GetNearestVehicleID(playerid, 3.0);
            if(vehicleid == INVALID_VEHICLE_ID) return 0;
            
            new Float:x, Float:y, Float:z;
            GetVehiclePos(vehicleid, x, y, z);
            if(!IsPlayerInRangeOfPoint(playerid, 3.0, x, y, z)) return 0;
        }
        
        if(vehicleid == INVALID_VEHICLE_ID) return 0;
        
        new Float:vehicle_health;
        GetVehicleHealth(vehicleid, vehicle_health);
        if(vehicle_health >= 999.0) return 0;
        
        RepairVehicle(vehicleid);
        SetVehicleHealth(vehicleid, 1000.0);
        ApplyAnimationEx(playerid, "CAR", "Fixn_Car_Loop", 4.0, 0, 0, 0, 0, 700, 1);
        PlayerPlaySound(playerid, 1133, 0.0, 0.0, 0.0);
        
        ConsumePlayerInventoryItem(playerid, inv_slot);
        slot_code = inv_slot;
        return 1;
    }

    // Ìàñêà
    // Маска
    if(IsInventoryMaskItem(itemid))
    {
        if(GetPlayerData(playerid, P_MASK) >= 2) return 0;
        
        SetPlayerData(playerid, P_MASK, 1);
        callcmd::mask(playerid, "");
        
        if(GetPlayerData(playerid, P_MASK) < 2)
        {
            SetPlayerData(playerid, P_MASK, 0);
            return 0;
        }
        
        ConsumePlayerInventoryItem(playerid, inv_slot);
        slot_code = inv_slot;
        return 1;
    }

    // Accessory with TXD editor
    if(IsInventoryAccessoryItem(itemid))
    {
        return UsePlayerInventoryAccessory(playerid, inv_slot, itemid, slot_code);
    }
    
    return 0;
}

stock RefreshInventoryView(playerid)
{
    if(!IsPlayerConnected(playerid)) return 0;

    new Node:json_close = JSON_Object();
    JSON_SetInt(json_close, "c", 1);
    OnPacketIncoming(playerid, 33, json_close);
    JSON_Cleanup(json_close);

    Inventory(playerid);
    return 1;
}

stock RemovePlayerItem(playerid, itemid, quantity)
{
    new inv_slots = GetPlayerInventorySlots(playerid);

    for(new i = 0; i < inv_slots; i++)
    {
        if(PlayerInventory[playerid][i][invItem] == itemid)
        {
            if(PlayerInventory[playerid][i][invCount] >= quantity)
            {
                PlayerInventory[playerid][i][invCount] -= quantity;
                if(PlayerInventory[playerid][i][invCount] <= 0)
                {
                    PlayerInventory[playerid][i][invItem] = 0;
                    PlayerInventory[playerid][i][invCount] = 0;
                    PlayerInventory[playerid][i][invValue] = 0;
                }
                return 1;
            }
            return 0;
        }
    }
    return 0;
}

stock AccessoryCloseInventoryGui(playerid)
{
    if(!IsPlayerConnected(playerid)) return 0;

    new Node:json_close = JSON_Object();
    JSON_SetInt(json_close, "c", 1);
    OnPacketIncoming(playerid, 33, json_close);
    JSON_Cleanup(json_close);
    return 1;
}

stock AccessoryClearPendingApplyVars(playerid)
{
    DeletePVar(playerid, "inv_acc_pending_apply");
    DeletePVar(playerid, "inv_acc_pending_inv_slot");
    DeletePVar(playerid, "inv_acc_pending_itemid");
    DeletePVar(playerid, "inv_acc_pending_attach_slot");
    DeletePVar(playerid, "inv_acc_pending_replaced");
    DeletePVar(playerid, "inv_acc_pending_replaced_itemid");
    DeletePVar(playerid, "inv_acc_pending_replaced_modelid");
    DeletePVar(playerid, "inv_acc_pending_old_model");
    DeletePVar(playerid, "inv_acc_pending_old_bone");
    DeletePVar(playerid, "inv_acc_pending_old_x");
    DeletePVar(playerid, "inv_acc_pending_old_y");
    DeletePVar(playerid, "inv_acc_pending_old_z");
    DeletePVar(playerid, "inv_acc_pending_old_rx");
    DeletePVar(playerid, "inv_acc_pending_old_ry");
    DeletePVar(playerid, "inv_acc_pending_old_rz");
    DeletePVar(playerid, "inv_acc_pending_old_sx");
    DeletePVar(playerid, "inv_acc_pending_old_sy");
    DeletePVar(playerid, "inv_acc_pending_old_sz");
    DeletePVar(playerid, "inv_acc_pending_db_id");
    return 1;
}

stock AccessoryRollbackPendingApply(playerid)
{
    if(!IsPlayerConnected(playerid)) return 0;
    if(!GetPVarInt(playerid, "inv_acc_pending_apply")) return 0;

    new attach_slot = GetPVarInt(playerid, "inv_acc_pending_attach_slot");
    if(attach_slot < 0 || attach_slot >= MAX_PLAYER_ATTACHED_OBJECTS) return 0;

    if(GetPVarInt(playerid, "inv_acc_pending_replaced"))
    {
        new old_model = GetPVarInt(playerid, "inv_acc_pending_old_model");
        new old_bone = GetPVarInt(playerid, "inv_acc_pending_old_bone");

        if(old_model > 0 && old_bone > 0)
        {
            new Float:ox = GetPVarFloat(playerid, "inv_acc_pending_old_x");
            new Float:oy = GetPVarFloat(playerid, "inv_acc_pending_old_y");
            new Float:oz = GetPVarFloat(playerid, "inv_acc_pending_old_z");
            new Float:orx = GetPVarFloat(playerid, "inv_acc_pending_old_rx");
            new Float:ory = GetPVarFloat(playerid, "inv_acc_pending_old_ry");
            new Float:orz = GetPVarFloat(playerid, "inv_acc_pending_old_rz");
            new Float:osx = GetPVarFloat(playerid, "inv_acc_pending_old_sx");
            new Float:osy = GetPVarFloat(playerid, "inv_acc_pending_old_sy");
            new Float:osz = GetPVarFloat(playerid, "inv_acc_pending_old_sz");

            SetPlayerAttachedObject(playerid, attach_slot, old_model, old_bone, ox, oy, oz, orx, ory, orz, osx, osy, osz, 0);
            AccessorySyncTempData(playerid, attach_slot, old_model, old_bone, ox, oy, oz, orx, ory, orz, osx, osy, osz);
        }
        else
        {
            RemovePlayerAttachedObject(playerid, attach_slot);
            AccessoryClearTempData(playerid, attach_slot);
        }
    }
    else
    {
        RemovePlayerAttachedObject(playerid, attach_slot);
        AccessoryClearTempData(playerid, attach_slot);
    }

    return 1;
}

stock UsePlayerInventoryAccessory(playerid, inv_slot, itemid, &slot_code)
{
    if(GetPVarInt(playerid, "inv_acc_pending_apply")) return 0;

    new active_slots = GetPlayerInventorySlots(playerid);
    if(inv_slot < 0 || inv_slot >= active_slots) return 0;
    if(PlayerInventory[playerid][inv_slot][invItem] != itemid) return 0;
    if(PlayerInventory[playerid][inv_slot][invCount] <= 0) return 0;

    new modelid = GetInventoryItemModelId(itemid);
    if(modelid <= 0) modelid = GetModelIdByInternalId(itemid);
    if(modelid <= 0) return 0;

    new free_slot = -1;
    for(new i = 0; i < MAX_PLAYER_ATTACHED_OBJECTS; i++)
    {
        if(!IsPlayerAttachedObjectSlotUsed(playerid, i))
        {
            free_slot = i;
            break;
        }
    }
    if(free_slot == -1) return 0;

    new inv_acc_slot = -1;
    for(new i = 0; i < INVENTORY_MAX_EQUIPPED_ACCESSORIES; i++)
    {
        if(gPlayerInvAccToAttachSlot[playerid][i] == -1)
        {
            inv_acc_slot = i;
            break;
        }
    }
    if(inv_acc_slot == -1) return 0;

    SetPlayerAttachedObject(playerid, free_slot, modelid, 2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
    AccessorySyncTempData(playerid, free_slot, modelid, 2, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0);
    SetInventoryAccessorySlot(playerid, inv_acc_slot, free_slot);

    AccessoryClearPendingApplyVars(playerid);
    SetPVarInt(playerid, "inv_acc_pending_apply", 1);
    SetPVarInt(playerid, "inv_acc_pending_inv_slot", inv_slot);
    SetPVarInt(playerid, "inv_acc_pending_itemid", itemid);
    SetPVarInt(playerid, "inv_acc_pending_attach_slot", free_slot);
    SetPVarInt(playerid, "inv_acc_pending_replaced", 0);
    SetPVarInt(playerid, "inv_acc_pending_replaced_itemid", -1);
    SetPVarInt(playerid, "inv_acc_pending_replaced_modelid", -1);
    SetPVarInt(playerid, "inv_acc_pending_db_id", AccessoryGetInventoryDbIdByModel(playerid, modelid));

    AccessoryCloseInventoryGui(playerid);

    if(!OpenAccessoryTextdrawEditorFromInventory(playerid, free_slot, modelid, 2, GetPVarInt(playerid, "inv_acc_pending_db_id")))
    {
        RemovePlayerAttachedObject(playerid, free_slot);
        AccessoryClearTempData(playerid, free_slot);
        AccessoryClearPendingApplyVars(playerid);
        return 0;
    }

    slot_code = -1;
    return 0;
}
CMD:giveitem(playerid, params[])
{
    new targetid, item, count;
    if(sscanf(params, "uii", targetid, item, count))
        return SendClientMessage(playerid, -1, "Usage: /giveitem [id] [item_id] [count]");

    if(targetid == INVALID_PLAYER_ID || !IsPlayerConnected(targetid))
        return SendClientMessage(playerid, -1, "Player not found.");

    if(count <= 0)
        return SendClientMessage(playerid, -1, "count must be greater than 0.");

    if(item == 134)
    {
        if(!GivePlayerSkin(targetid, count))
            return SendClientMessage(playerid, -1, "Could not give skin (no free slots)."), 1;

        SendClientMessage(playerid, -1, "Skin added to inventory.");
        RefreshInventoryView(targetid);
        return 1;
    }

    if(!GivePlayerItem(targetid, item, count))
        return SendClientMessage(playerid, -1, "Could not give item (no free slots)."), 1;

    SendClientMessage(playerid, -1, "Item added to inventory.");
    RefreshInventoryView(targetid);
    return 1;
}

CMD:addskin(playerid, params[])
{
    new targetid, skin;
    if(sscanf(params, "ui", targetid, skin))
        return SendClientMessage(playerid, -1, "Usage: /addskin [id] [skin_id]");

    if(targetid == INVALID_PLAYER_ID || !IsPlayerConnected(targetid))
        return SendClientMessage(playerid, -1, "Player not found.");

    if(skin <= 0)
        return SendClientMessage(playerid, -1, "Invalid skin_id.");

    if(!GivePlayerSkin(targetid, skin))
        return SendClientMessage(playerid, -1, "No free inventory slots."), 1;

    SendClientMessage(playerid, -1, "Skin added to inventory.");
    RefreshInventoryView(targetid);
    return 1;
}

